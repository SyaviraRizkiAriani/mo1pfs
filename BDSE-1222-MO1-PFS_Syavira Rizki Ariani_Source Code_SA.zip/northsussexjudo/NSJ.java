package northsussexjudo;

public class NSJ {

	public static void main(String[] args) {
		     InputUser obj = new InputUser ();
		obj.inputData();
	obj.CalculatePrice ();
	   obj.OutPut();
		
//CalculatePrice obj1 = new Calculate price ()
	}


	}


