package northsussexjudo;

public class Entity {


     String name;
    char decision;
    String trainingPlan;
    double currentWeight;
    String competitionWeightCategory;
    int competitionsEntered;
    int privateCoachingCost;
	char decision1;
	double currentweight;
	String weightCategory;
	double weightCategotyDouble;
	int numsOfCompetition;
	int numsOfPrivateSession;
	double totalCost;
	double planCost;
	double compCost;
	double priCost;
	String beginner = "Beginner";
	String intermediate = "Intermediate";
	String elite = "Elite";
    
    // Create getters and setters for each property
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
        
    }
	public char getDecision() {
		return decision;
	}
	public void setDecision(char decision) {
		this.decision = decision;
	}
	public char getDecision1() {
		return decision1;
	}
	public void setDecision1(char decision1) {
		this.decision1 = decision1;
    }
    public String getTrainingPlan() {
        return trainingPlan;
    }
    public void setTrainingPlan(String trainingPlan) {
        this.trainingPlan = trainingPlan;
    }
    public double getCurrentWeight() {
        return currentWeight;
    }
    public void setCurrentWeight(double currentWeight) {
        this.currentWeight = currentWeight;
    }
    public String getCompetitionWeightCategory() {
        return competitionWeightCategory;
    }
    public void setCompetitionWeightCategory(String competitionWeightCategory) {
        this.competitionWeightCategory = competitionWeightCategory;
    }
    public int getCompetitionsEntered() {
        return competitionsEntered;
    }
    public void setCompetitionsEntered(int competitionsEntered) {
        this.competitionsEntered = competitionsEntered;
    }
    public double getPrivateCoachingCost() {
        return privateCoachingCost;
    }
    public void setPrivateCoachingCost(int privateCoachingCost) {
        this.privateCoachingCost = privateCoachingCost;
    }




public String getWeightCategory() {
	return weightCategory;
}
public void setWeightCategory(String weightCategory) {
	this.weightCategory = weightCategory;
}
public double getWeightCategotyDouble() {
	return weightCategotyDouble;
}
public void setWeightCategotyDouble(double weightCategotyDouble) {
	this.weightCategotyDouble = weightCategotyDouble;
}
public int getNumsOfCompetition() {
	return numsOfCompetition;
}
public void setNumsOfCompetition(int numsOfCompetition) {
	this.numsOfCompetition = numsOfCompetition;
}
public int getNumsOfPrivateSession() {
	return numsOfPrivateSession;
}
public void setNumsOfPrivateSession(int numsOfPrivateSession) {
	this.numsOfPrivateSession = numsOfPrivateSession;
	
	
	
	
	
	
	
	
	
	
}
public double getTotalCost( ) {
	return totalCost;
}
public void setTotalCost(double totalCost) {
	this.totalCost = totalCost;
}
public double getPlanCost() {
	return planCost;
}
public void setPlanCost(double planCost) {
	this.planCost = planCost;
}
public double getCompCost() {
	return compCost;
}
public void setCompCost(double compCost) {
	this.compCost = compCost;
}
public double getPriCost() {
	return priCost;
}
public void setPriCost(double priCost) {
	this.priCost = priCost;
}
public String getBeginner() {
	return beginner;
}
public void setBeginner(String beginner) {
	this.beginner = beginner;
}
public String getIntermediate() {
	return intermediate;
}
public void setIntermediate(String intermediate) {
	this.intermediate = intermediate;
}
public String getElite() {
	return elite;
}
public void setElite(String elite) {
	this.elite = elite;
}

			
		
		
		
			
			
		
		
		
		
			
			
			
			
		
			

		
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
