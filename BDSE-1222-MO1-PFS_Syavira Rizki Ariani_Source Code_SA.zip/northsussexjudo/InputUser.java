package northsussexjudo;

import java.util.Scanner; 

public class InputUser extends Entity{
	
	public static void main(String[] args) {
		InputUser userInput = new InputUser();
        userInput.inputData();
 //       CalculatePrice userOutput = new CalculatePrice();
 //       userOutput.Output();
 //       CalculatePrice calc = new CalculatePrice();
 //       cal.Calc();
	}

		public void inputData() {
			 String name;
			 //String trainingPlan;
			 //Entity athlete = new Entity();
		     Scanner input = new Scanner(System.in);
		     
		     

		     System.out.println("Welcome to North Sussex Judo Training fee!"
						+ "\n");{
		     String regex = "^[a-zA-Z]*$";
				while(true) {			
				System.out.print("Enter your name: ");
		        name = input.nextLine();
				    if (name.matches(regex)) {
				    	setName(name);
				    	break;
				    } else {
				    	System.out.println("Invalid name format. Please enter your name in the format of FirstName LastName' with first latter of the name uppercase");
				    	System.out.println("Name must have minimum of 1 word  with A-Z character only!");
				    }
				    }

		        
	
		        Boolean yn= true;
	    		while(yn) {
	    			
	    			String elite = "Elite";
	    			String beginner = "Beginner";
	    			String intermediate = "Intermediate";
			    
     		    	System.out.println("Please select the training plan!");
			    	System.out.println("Beginner - 2 sessions Per week - $25.00");
			    	System.out.println("Intermediate - 3 sessions Per week - $30.00");
			    	System.out.println("Elite - 5 sessions Per week - $35.00");
			    	System.out.println("Please note above plans above are weekly fee");
			    	System.out.print("Enter training plan: ");
			    	setTrainingPlan(input.next());
			    	if(getTrainingPlan().equalsIgnoreCase(elite) || getTrainingPlan().equalsIgnoreCase(intermediate)) {
			    		while (yn) {
							System.out.println("Do you want to enroll competition for additional $22.00? (Y/N) ");
							decision = input.next().charAt(0);
								if(getDecision() == 'Y') {
									setNumsOfCompetition(1);
								yn = false;
								break;
								}else if (getDecision() == 'N') {
									setNumsOfCompetition(0);
									yn = false;
									break;
								}else {
									System.out.println("please enter again!");
								}
			    		}
			    	}else if (getTrainingPlan().equalsIgnoreCase(beginner)){
			    		setNumsOfCompetition(0);
			    		break;
			    	}else {
			    	
			    	}
			    	
			    		System.out.println("Please enter the existing plan only!");
			    	}
	    		
	    		while(true) {
	    			
	    			System.out.println("__________________________________________________________");
	    			System.out.println("|      Weight Category      |   Upper Weight Limit (Kg)  |");
	    			System.out.println("|---------------------------|----------------------------|");
	    			System.out.println("|Heavyweight                |Unlimeted (Over 100)        |");
	    			System.out.println("|Light-Heavyweight          |100                         |");
	    			System.out.println("|Middleweight               |90                          |");
	    			System.out.println("|Light-Middleweight         |81                          |");
	    			System.out.println("|Lightweight                |73                          |");
	    			System.out.println("|Flyweight                  |66                          |");
	    			System.out.println("|---------------------------|----------------------------|");
	    			int Heavyweight = 101;
	    			int LightHeavyweight =100;
	    			int MiddleWeight = 90;
	    			int LightMiddleWeight = 81;
	    			int LightWeight = 73;
	    			int Flyweight = 66;
	    			System.out.println("Enter your weight(in Kg): ");
	    			setCurrentWeight(input.nextInt());
	    			if (getCurrentWeight() > 100.00) {
	    				setWeightCategory("Heavyweight");
	    				setWeightCategotyDouble(Heavyweight);
	    				break;
	    			}else if (getCurrentWeight() > 90.00 && getCurrentWeight() < 101.00) {
	    				setWeightCategory("Light-Heavyweight");
	    				setWeightCategotyDouble(LightHeavyweight);
	    				break;
	    			}else if (getCurrentWeight() > 81.00 && getCurrentWeight() < 91.00) {
	    				setWeightCategory("MiddleWeight");
	    				setWeightCategotyDouble(MiddleWeight);
	    				break;
	    			}else if (getCurrentWeight() > 73.00 && getCurrentWeight() < 82.00) {
	    				setWeightCategory("Light-MiddleWeight");
	    				setWeightCategotyDouble(LightMiddleWeight);
	    				break;
	    			}else if (getCurrentWeight() > 66.00 && getCurrentWeight() < 74.00) {
	    				setWeightCategory("Light-Weight");
	    				setWeightCategotyDouble(LightWeight);
	    				break;
	    			}else if (getCurrentWeight() > 00.00 && getCurrentWeight() < 67.00) {
	    				setWeightCategory("FlyWeight");
	    				setWeightCategotyDouble(Flyweight);
	    				break;
	    			}else {
	    				System.out.println("Please sync the existing menu!");
	    			}
	    		}
	    			
	    			System.out.println("Private Session -- $9.00 per hour -- Maximum 5 hours a week");
	    			boolean yn2 = true;
	    			while (yn2) {
	    				
	    				System.out.println("Do you want to enroll for private coaching? (Y/N)");
	    				setDecision1(input.next().charAt(0));
	    				if(getDecision1() == 'Y') {
	    					while(true) {
	    						System.out.println("How many hours would you like to enroll for private coaching weekly for a month? (5 Hours Max Weekly)");
	    						setNumsOfPrivateSession(input.nextInt());
	    						if(getNumsOfPrivateSession() > 5) {
	    							System.out.println("Cannot exceed maximum hours weekly! Please Try again!");
	    							System.out.println("Choose N instead of input 0 hours!");
	    						}else {
	    							break;
	    						}
	    					}break;
	    				}else if (getDecision1() == 'N') {
	    					setNumsOfPrivateSession(0);
	    					break;
	    				}else if (!(getDecision1() == 'Y' || getDecision1() == 'N')) {
	    					System.out.println("Please Try Again!");
	    				}
	    				
	    			}
						}
	    			}
		
	   
		public void CalculatePrice() {
			 
			 
			 if(getTrainingPlan().equalsIgnoreCase(getElite())) {
					setPlanCost(35.00);
					
					
				}else if (getTrainingPlan().equalsIgnoreCase(getIntermediate())) {
					setPlanCost(30.00);
				}else {
					setPlanCost(25.00);
					
				}
				if(getNumsOfCompetition() == 1) {
					setCompCost(22.00);
				}else {
					setCompCost(0);		
				}
				if(getDecision1() == 'Y') {
					setPriCost(9.00 * getNumsOfPrivateSession() * 4);
				}else {
					setPriCost(0);
				}
				setTotalCost(getPlanCost() + getCompCost() + getPriCost());
			}
		
		public void OutPut() {
			System.out.println("Hello " +getName()+"!");
			System.out.println("There are the itemised cost for your monthly training:");
			System.out.println("Training Plan Cost: $"+getPlanCost());
			System.out.println("Competition Cost: $"+getCompCost());
			System.out.println("Private Coaching Cost for a month: $"+getPriCost());
			System.out.println("The total cost of training for the month: $"+getTotalCost());
			if(getWeightCategotyDouble() != getCurrentWeight()) {
				double weightComparison = (getWeightCategotyDouble() -getCurrentWeight());
				System.out.println("You need to gain "+weightComparison+"Kg to be eligible for the "+getWeightCategory()+" Competition!");
			}else if (getWeightCategotyDouble() == getCurrentWeight()) {
				double weightComparasion = 0;
				System.out.println("You are eligible for the "+getWeightCategory()+"Competition because you have "+weightComparasion+"weight gap!");
			}
		}  	 
		 
			
		
								
							
							
						
				
				
				
		     
			    
						
				
					
				
		     

			
		 
		   
			
		
			

		    

	
}
